#include <fstream>
#include <iostream>
using namespace std;

void directAccess(const string& filename, int position) {
    ifstream file(filename, ios::binary); // İkili modda dosya açılır.
    if (!file) {
        cerr << "Dosya açılamadı: " << filename << endl;
        return;
    }

    file.seekg(position); // Belirtilen pozisyona gidilir.

    char buffer[100];
    file.read(buffer, sizeof(buffer)); // Pozisyondan itibaren veriler okunur.

    cout << "Okunan veri: " << buffer << endl;

    file.close();
}

int main() {
    directAccess("example.dat", 10); // 10. byte'tan itibaren 100 byte okunur.
    return 0;
}
