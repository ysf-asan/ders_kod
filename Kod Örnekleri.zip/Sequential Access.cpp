#include <fstream>
#include <iostream>
#include <string>
using namespace std;

void sequentialAccess(const string& filename) {
    ifstream file(filename);
    string line;

    if (!file) {
        cerr << "Dosya açılamadı: " << filename << endl;
        return;
    }

    while (getline(file, line)) {
        // Dosyadan satır satır okuma işlemi yapılır ve her satır ekrana yazdırılır.
        cout << line << endl;
    }

    file.close();
}

int main() {
    sequentialAccess("example.txt");
    return 0;
}
