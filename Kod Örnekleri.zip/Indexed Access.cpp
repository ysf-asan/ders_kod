#include <fstream>
#include <iostream>
#include <map>
#include <string>
using namespace std;

map<string, long> buildIndex(const string& filename) {
    ifstream file(filename);
    map<string, long> index;
    string line;
    long position = 0;

    if (!file) {
        cerr << "Dosya açılamadı: " << filename << endl;
        return index;
    }

    while (getline(file, line)) {
        string key = line.substr(0, line.find(' ')); // Her satırın başındaki kelimeyi anahtar olarak alır.
        index[key] = position; // Anahtar ve pozisyonu indekse ekler.
        position = file.tellg(); // Sonraki okuma pozisyonunu günceller.
    }

    file.close();
    return index;
}

void searchByKey(const string& filename, const map<string, long>& index, const string& key) {
    auto it = index.find(key);
    if (it == index.end()) {
        cout << "Anahtar bulunamadı: " << key << endl;
        return;
    }

    ifstream file(filename);
    file.seekg(it->second);
    string line;
    getline(file, line);
    cout << "Bulunan satır: " << line << endl;

    file.close();
}

int main() {
    string filename = "example.txt";
    auto index = buildIndex(filename);
    searchByKey(filename, index, "AnahtarKelime");
    return 0;
}
